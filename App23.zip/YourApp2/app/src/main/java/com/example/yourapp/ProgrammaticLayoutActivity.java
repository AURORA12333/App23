package com.example.yourapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ProgrammaticLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Создаем основной контейнер LinearLayout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL); // Вертикальная ориентация
        layout.setPadding(16, 16, 16, 16); // Добавляем отступы

        // Заголовок "Регистрация"
        TextView title = new TextView(this);
        title.setText("Регистрация");
        title.setGravity(android.view.Gravity.CENTER); // Выравнивание по центру
        title.setTextSize(24); // Размер текста
        layout.addView(title); // Добавляем заголовок в контейнер

        // Поле ввода имени
        EditText nameInput = new EditText(this);
        nameInput.setHint("Введите имя");
        nameInput.setPadding(8, 8, 8, 8); // Отступы внутри поля
        layout.addView(nameInput); // Добавляем поле ввода имени

        // Поле ввода E-mail
        EditText emailInput = new EditText(this);
        emailInput.setHint("Введите e-mail");
        emailInput.setPadding(8, 8, 8, 8); // Отступы внутри поля
        layout.addView(emailInput); // Добавляем поле ввода E-mail

        // Поле ввода пароля
        EditText passwordInput = new EditText(this);
        passwordInput.setHint("Введите пароль");
        passwordInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setPadding(8, 8, 8, 8); // Отступы внутри поля
        layout.addView(passwordInput); // Добавляем поле ввода пароля

        // Кнопка "Зарегистрироваться"
        Button registerButton = new Button(this);
        registerButton.setText("Зарегистрироваться");
        registerButton.setPadding(16, 8, 16, 8); // Отступы кнопки
        layout.addView(registerButton); // Добавляем кнопку

        // Устанавливаем созданный layout как содержимое активити
        setContentView(layout);
    }
}