package com.example.yourapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Кнопка для LinearLayout
        Button buttonLinear = findViewById(R.id.buttonLinear);
        buttonLinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LinearActivity.class));
            }
        });

        // Кнопка для TableLayout
        Button buttonTable = findViewById(R.id.buttonTable);
        buttonTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, TableActivity.class));
            }
        });

        // Кнопка для FrameLayout
        Button buttonFrame = findViewById(R.id.buttonFrame);
        buttonFrame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, FrameActivity.class));
            }
        });

        // Кнопка для RelativeLayout
        Button buttonRelative = findViewById(R.id.buttonRelative);
        buttonRelative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RelativeActivity.class));
            }
        });

        // Кнопка для ConstraintLayout
        Button buttonConstraint = findViewById(R.id.buttonConstraint);
        buttonConstraint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ConstraintActivity.class));
            }
        });

        // Кнопка для ScrollView
        Button buttonScroll = findViewById(R.id.buttonScroll);
        buttonScroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ScrollActivity.class));
            }
        });

        // Кнопка для GridLayout
        Button buttonGrid = findViewById(R.id.buttonGrid);
        buttonGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, FrameActivity.class));
            }
        });
    }
}