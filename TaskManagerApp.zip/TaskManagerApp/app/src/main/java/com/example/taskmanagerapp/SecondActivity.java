package com.example.taskmanagerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView tvOrderSummary = findViewById(R.id.tvOrderSummary);
        Button btnBack = findViewById(R.id.btnBack);

        // Получение данных из первого экрана
        Intent intent = getIntent();
        String orderSummary = intent.getStringExtra("order_summary");
        if (orderSummary != null) {
            tvOrderSummary.setText(orderSummary);
        } else {
            tvOrderSummary.setText("Нет данных о заказе");
        }

        // Кнопка "Назад"
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}