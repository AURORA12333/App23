package com.example.taskmanagerapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvRandomNumber;
    private Button btnGenerateNumber;
    private EditText etInputText;
    private Button btnInvertText;
    private TextView tvInvertedText;
    private Button btnStartStop;
    private CheckBox cbShopping;
    private CheckBox cbLunch;
    private CheckBox cbReadBook;
    private TextView tvTaskResult;
    private RadioGroup rgBread;
    private RadioGroup rgDrink;
    private Button btnSendOrder;
    private Spinner spColor;
    private TextView tvColoredText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация виджетов
        tvRandomNumber = findViewById(R.id.tvRandomNumber);
        btnGenerateNumber = findViewById(R.id.btnGenerateNumber);
        etInputText = findViewById(R.id.etInputText);
        btnInvertText = findViewById(R.id.btnInvertText);
        tvInvertedText = findViewById(R.id.tvInvertedText);
        btnStartStop = findViewById(R.id.btnStartStop);
        cbShopping = findViewById(R.id.cbShopping);
        cbLunch = findViewById(R.id.cbLunch);
        cbReadBook = findViewById(R.id.cbReadBook);
        tvTaskResult = findViewById(R.id.tvTaskResult);
        rgBread = findViewById(R.id.rgBread);
        rgDrink = findViewById(R.id.rgDrink);
        btnSendOrder = findViewById(R.id.btnSendOrder);
        spColor = findViewById(R.id.spColor);
        tvColoredText = findViewById(R.id.tvColoredText);

        // Генерация случайного числа
        btnGenerateNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                int randomNumber = random.nextInt(100) + 1;
                tvRandomNumber.setText("Случайное число: " + randomNumber);
            }
        });

        // Инвертирование строки
        btnInvertText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = etInputText.getText().toString();
                StringBuilder reversedText = new StringBuilder(inputText).reverse();
                tvInvertedText.setText(reversedText.toString());
            }
        });

        // Кнопка "Старт/Стоп"
        final boolean[] isStarted = {false};
        btnStartStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isStarted[0]) {
                    btnStartStop.setText("Стоп");
                    System.out.println("Запись пошла...");
                    isStarted[0] = true;
                } else {
                    btnStartStop.setText("Старт");
                    System.out.println("Запись остановлена...");
                    isStarted[0] = false;
                }
            }
        });

        // Обработка чекбоксов
        cbShopping.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                tvTaskResult.setText("Вы сделали задание: " + cbShopping.getText());
            } else {
                tvTaskResult.setText("");
            }
        });

        cbLunch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                tvTaskResult.setText("Вы сделали задание: " + cbLunch.getText());
            } else {
                tvTaskResult.setText("");
            }
        });

        cbReadBook.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                tvTaskResult.setText("Вы сделали задание: " + cbReadBook.getText());
            } else {
                tvTaskResult.setText("");
            }
        });

        // Отправка заказа
        btnSendOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedBread = "";
                String selectedDrink = "";

                int breadId = rgBread.getCheckedRadioButtonId();
                if (breadId == R.id.rbWhiteBread) {
                    selectedBread = "белый хлеб";
                } else if (breadId == R.id.rbBlackBread) {
                    selectedBread = "чёрный хлеб";
                } else {
                    selectedBread = "не выбран хлеб";
                }

                int drinkId = rgDrink.getCheckedRadioButtonId();
                if (drinkId == R.id.rbTea) {
                    selectedDrink = "чай";
                } else if (drinkId == R.id.rbJuice) {
                    selectedDrink = "сок";
                } else if (drinkId == R.id.rbWater) {
                    selectedDrink = "минеральная вода";
                } else {
                    selectedDrink = "не выбран напиток";
                }

                String orderSummary = "Вы заказали: " + selectedBread + " и " + selectedDrink;

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("order_summary", orderSummary);
                startActivity(intent);
            }
        });

        // Изменение цвета метки
        spColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String color = parent.getItemAtPosition(position).toString();
                if (color.equals("Красный")) {
                    tvColoredText.setTextColor(Color.RED);
                } else if (color.equals("Жёлтый")) {
                    tvColoredText.setTextColor(Color.YELLOW);
                } else if (color.equals("Синий")) {
                    tvColoredText.setTextColor(Color.BLUE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }
}